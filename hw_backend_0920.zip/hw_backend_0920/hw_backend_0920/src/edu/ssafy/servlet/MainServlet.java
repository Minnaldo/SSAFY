package edu.ssafy.servlet;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ssafy.model.ProductManager;
import edu.ssafy.model.ProductVO;

/**
 * Servlet implementation class MainServlet
 */
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ProductManager productManager = ProductManager.getInstance();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		if (action.equals("regist")) {
			registPro(request, response);
		} else if (action.equals("listpro")) {
	         List<ProductVO> proList = productManager.getProductList();
	         request.setAttribute("proList", proList);
	         request.getRequestDispatcher("listpro.jsp").forward(request, response);
		} else if (action.equals("viewpro")) {
			proInfo(request, response);
		}
	}

	private void proInfo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {		
		String name = request.getParameter("uid");
		List<ProductVO> proList = new ArrayList<ProductVO>();
		proList.add(productManager.getMember(name));
	    request.setAttribute("proList", proList);
	    request.getRequestDispatcher("listpro.jsp").forward(request, response);
	}

	private void registPro(HttpServletRequest request, HttpServletResponse response)
			throws UnsupportedEncodingException, IOException {
		// 회원추가작업해주고 메인으로
		// 파라메터들을 모두 꺼내서 MemberVO객체로 묶어서 매니저의 addMember함수에 던져주자
		int isbn = Integer.parseInt(request.getParameter("pisbn"));
		String name = request.getParameter("pname");
		int price = Integer.parseInt(request.getParameter("pprice"));
		String info = request.getParameter("pinfo");
		ProductVO productVO = new ProductVO(isbn, name, price, info);

		boolean res = productManager.addMember(productVO);
		if (res) {
			// request.setAttribute("result", id + " 등록 성공");
			// request.getSession().setAttribute("result", id + " 등록 성공");
			response.sendRedirect("result.jsp?result=" + isbn + URLEncoder.encode(" 등록 성공", "UTF-8"));
		} else {
			// request.setAttribute("result", id + " 등록 실패");
			String msg = URLEncoder.encode(" 등록 실패", "UTF-8");
			response.sendRedirect("result.jsp?result=" + isbn + msg);
		}

	}

}
