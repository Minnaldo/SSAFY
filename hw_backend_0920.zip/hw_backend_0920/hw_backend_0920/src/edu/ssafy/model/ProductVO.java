package edu.ssafy.model;

public class ProductVO {
	private int isbn;
	private String name;
	private int price;
	private String info;
	
	
	public ProductVO() {
		
	}
	public ProductVO(int isbn, String name, int price, String info) {
		super();
		this.isbn = isbn;
		this.name = name;
		this.price = price;
		this.info = info;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	@Override
	public String toString() {
		return "ProductVO [isbn=" + isbn + ", name=" + name + ", price=" + price + ", info=" + info + "]";
	}
	
	
	
}
