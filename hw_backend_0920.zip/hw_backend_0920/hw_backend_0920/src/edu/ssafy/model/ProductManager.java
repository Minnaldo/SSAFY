package edu.ssafy.model;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;

	public class ProductManager {
		private Connection conn;
		private PreparedStatement pst;
		private ResultSet rs;

			private static ProductManager man = new ProductManager();
			private ProductManager() {}
			public static ProductManager getInstance() {
				return man;
			}

		public boolean addMember(ProductVO productVO) {
			String str = "insert into protb(isbn, name, price, info) values(?, ?, ?, ?)";
			int result = 0;
			try {
				conn = ConnectionProxy.getConnection();
				pst = conn.prepareStatement(str);
				pst.setInt(1, productVO.getIsbn());
				pst.setString(2, productVO.getName());
				pst.setInt(3, productVO.getPrice());
				pst.setString(4, productVO.getInfo());
				result = pst.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				close();
			}
			return result > 0 ? true : false;
		}

		public ProductVO getMember(String name) {
			String sql = "select * from protb where name = ?";
			ProductVO vo = null;
			try {
				conn = ConnectionProxy.getConnection();
				pst = conn.prepareStatement(sql);
				pst.setString(1, name);
				rs = pst.executeQuery();
				if (rs.next()) {
					vo = new ProductVO();
					vo.setIsbn(rs.getInt("isbn"));
					vo.setName(rs.getString("name"));
					vo.setPrice(rs.getInt("price"));
					vo.setInfo(rs.getString("info"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				close();
			}
			return vo;
		}

		public List<ProductVO> getProductList() {
			String sql = "select * from protb";
			ArrayList<ProductVO> list = null;
			try {
				conn = ConnectionProxy.getConnection();
				pst = conn.prepareStatement(sql);
				rs = pst.executeQuery();
				list = new ArrayList();
				while (rs.next()) {
					ProductVO vo = new ProductVO();
					vo.setIsbn(rs.getInt("isbn"));
					vo.setName(rs.getString("name"));
					vo.setPrice(rs.getInt("price"));
					vo.setInfo(rs.getString("info"));

					list.add(vo);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				close();
			}
			return list;
		}
		
		public boolean delPro(int isbn) {
		      String str = "delete from protb where isbn = ?";
		      boolean res = false;
		      try {
		         conn = ConnectionProxy.getConnection();

		         pst = conn.prepareStatement(str);
		         pst.setInt(1, isbn);
		         pst.execute();
		         res = true;
		      } catch (SQLException e) {
		         // TODO Auto-generated catch block
		         e.printStackTrace();
		         res = false;
		      } finally {
		         close();
		      }
		      return res;
		   }

		public void close() {
			try {
				if (rs != null)
					rs.close();
				if (pst != null)
					pst.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}
