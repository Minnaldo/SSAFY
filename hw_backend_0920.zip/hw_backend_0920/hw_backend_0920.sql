Create database product;
use product;

create table protb(
	isbn int primary key,
    name varchar(200), 
    price int,
    info varchar(100)
);
    