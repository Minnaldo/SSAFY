package ssafy_HW;

public class TV {
	private String product_num;	
	private String product_name;
	private int	price;
	private int num;
	private int inch;
	private String display_type;
	
	TV() {}
	
	public TV(String product_num, String product_name, int price, int num, int inch, String display_type) {
		this.product_num = product_num;
		this.product_name = product_name;
		this.price = price;
		this.num = num;
		this.inch = inch;
		this.display_type = display_type;
	}

	public String getProduct_num() {
		return product_num;
	}
	public void setProduct_num(String product_num) {
		this.product_num = product_num;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getInch() {
		return inch;
	}
	public void setInch(int inch) {
		this.inch = inch;
	}
	public String getDisplay_type() {
		return display_type;
	}
	public void setDisplay_type(String display_type) {
		this.display_type = display_type;
	}
	
	
	@Override
	public String toString() {
		return "TV [product_num=" + product_num + ", product_name=" + product_name + ", price=" + price + ", num=" + num
				+ ", inch=" + inch + ", display_type=" + display_type + "]";
	}
	
}
