package edu.ssafy;

import java.util.ArrayList;

public interface IService {
	public ArrayList<Calc> calc(int a, int b);
}
