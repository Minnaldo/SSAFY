package edu.ssafy;

import java.util.ArrayList;

public interface IService {
	ArrayList<Calc> calc(int a,int b);
}
